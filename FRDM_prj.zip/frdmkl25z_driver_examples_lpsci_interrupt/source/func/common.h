/**
*	@file 			common.h
*	@brief 		Some common functions for this project
*	
*
*	@author 		
*	@date 			Feb 18 2019 
*	@version  	1.0
*/
#ifndef  __COMMON__
#define __COMMON__
//#include <time.h>

#include "board.h"
#include "fsl_lpsci.h"
#include "clock_config.h"
#include "pin_mux.h"
#define MAX_BLOCK (100)
#define MAX_SIZE (0xffffffff)
#define MAX_U32 (0xffffffff)
#define DASHA ((UINT64_t)(0-1))
#define NSEC_PER_SEC (1000000000)
#define NSEC_PER_MSEC (1000000)
#define NSEC_PER_MICROSEC (1000)
#define modulus ((UINT64_t)2147483648)
#define multiplier ((UINT64_t)1103515245)
#define increment ((UINT64_t)12345)
#define RANDOM_MAX ((UINT64_t)2147483648)
/*******************************************************************************
 * UART port Definitions
 ******************************************************************************/
#define DEMO_LPSCI UART0
#define DEMO_LPSCI_CLKSRC kCLOCK_CoreSysClk
#define DEMO_LPSCI_CLK_FREQ CLOCK_GetFreq(kCLOCK_CoreSysClk)
#define DEMO_LPSCI_IRQn UART0_IRQn
#define DEMO_LPSCI_IRQHandler UART0_IRQHandler

#define PRINTF  \
		LPSCI_WriteBlocking(DEMO_LPSCI,(UINT8_t *)uplink_buffer,uart_num);


typedef struct param param; 
typedef unsigned long long UINT64_t;
typedef long long INT64_t;
typedef int INT32_t;
typedef unsigned int UINT32_t;
typedef char INT8_t ;
typedef unsigned char UINT8_t ;

typedef struct{
	UINT32_t* mem_ptr;
	UINT32_t range;
	INT8_t obsolete;
}mem_array;

struct param
{
	UINT64_t param1;
	UINT64_t param2;
	UINT64_t param3;
	UINT64_t param4;  
	UINT64_t param5;
};
extern struct param output;
///memory utility

typedef void (*evt_ptr_type)(param*);
extern evt_ptr_type evt_ptr;
extern mem_array mem[MAX_BLOCK];

//uart transmission buffer
extern UINT32_t uart_num;
extern char uplink_buffer[255];

//timing function declaration
#define CLOCK_REALTIME (0)
#define NSEC_PER_10USEC (10000)
struct timespec {
	INT32_t   tv_sec;        /* seconds */
	INT64_t  tv_nsec;       /* nanoseconds */
};


void clock_gettime(INT8_t clkid, struct timespec* tp);
/**
*	@brief 		Check the memory is full or not
*	
*	@param 		addr		parameter string
*	
*	@return 		
*	-	 0				ERROR		(number of block is reach the maximum value)
*	-	-1				SUCCESS  	(memory is allocated)
*/
INT8_t check_addr(UINT64_t addr);

/**
*	@brief 		Check the memory is full or not
*	
*	@param 		blk_index		index of block has been allocated
*	@param 		offset 			index of address in the block
*	
*	@return 		res	
*	-	 0				ERROR		(offset value out of range |  block index is invalid)
*	-	-1				SUCCESS  	
*/
INT8_t check_blk(UINT32_t blk_index, UINT32_t offset);
void print_data(UINT32_t* base,UINT32_t range);
INT8_t align_addr_check(UINT64_t addr);
int delta_t(struct timespec *stop, struct timespec *start, struct timespec *delta_t);
#endif
