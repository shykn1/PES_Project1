/**
*	@file 			systick.c
*	@brief 		source file for the timing function on the FRDM
*	@author 		
*	@date 			Feb 24 2019 
*	@version  	1.0
*/

#include "common.h"
extern UINT64_t us_10;
extern UINT32_t second;

void clock_gettime(INT8_t clkid, struct timespec* tp){
	tp->tv_sec = second;
	tp->tv_nsec =us_10*NSEC_PER_10USEC;
}


