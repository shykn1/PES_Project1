/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "common.h"

#include "parser.h"
#include "allocate.h"
#include "free_mem.h"
#include "display.h"
#include "write_mem.h"
#include "invert.h"
#include "PRG.h"
#include "pattern_check.h"
#include <stdio.h>


/*! @brief Ring buffer size (Unit: Byte). */
#define DEMO_RING_BUFFER_SIZE 16

/*! @brief Ring buffer to save received data. */

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
//RX buffer, flag, and bookkeeper
volatile char command_flag = 0;
volatile char buffer[255];
volatile unsigned char buffer_ptr;
volatile UINT32_t cnt_charactor =0;

extern uint32_t SystemCoreClock;
volatile INT64_t us_10;
volatile INT32_t second;

/*******************************************************************************
 * Code
 ******************************************************************************/

void DEMO_LPSCI_IRQHandler(void)
{
    uint8_t data;

    /* If new data arrived. */
    if ((kLPSCI_RxDataRegFullFlag)&LPSCI_GetStatusFlags(DEMO_LPSCI))
    {
        data = LPSCI_ReadByte(DEMO_LPSCI);

		if( (data=='\n')||(data=='\r')){
			command_flag =1;
			data='\0';
		}
		else
			cnt_charactor++;


		buffer[buffer_ptr++] =data;
    }
}
void SysTick_Handler(void)  {                               /* SysTick interrupt Handler.
                                                    See startup file startup_LPC17xx.s for SysTick vector */
	us_10++;
	if(us_10==100000){
		us_10=0;
		second++;
//	    uart_num=sprintf((char*) uplink_buffer,"System clock: %ld\n",second);
//	    PRINTF;
	}
}

/**
*	@brief 		Printf the information for users while program starting
*
*	@return   	void.
*/
void inital_message(){
	uart_num=sprintf(uplink_buffer,"Press command starting with a \"C\": C0 means command 0 and C1 means command 1\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"Command 0: help; Command 1:exit\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To find More detail, use help\r\n");PRINTF;

};


/**
*	@brief 		Printf the information for users while receiving C0
*
*	@return   	void.
*/
void help_message(param* params_input){
	uart_num=sprintf(uplink_buffer,"Command 0: help; Command 1:exit\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To allocate a block: C2 <N of words in Hex>\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To free a block: C3 <index of the block>\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To display a range of memory with block and offset: C4 <index of the block> <offset> <range in terms of words(4-byte)>\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To display a range of memory with absolute address: C4 <addr> <range in terms of words(4-byte)> -a\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To write an location with block and offset: C5 <index of the block> <offset> <data in HEX>\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To write an location with absolute address: C5 <addr> <data in HEX> -a\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To invert a range of memory with block and offset: C6 <index of the block> <offset> <range in terms of words(4-byte)>\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To invert a range of memory with absolute address: C6 <addr> <range in terms of words(4-byte)> -a\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To write data pattern with block and offset: C7 <index of the block> <offset> <range in terms of words(4-byte)> <seed>\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To write data pattern with absolute address: C7 <addr> <range in terms of words(4-byte)> <seed> -a\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To check data pattern with block and offset: C8 <index of the block> <offset> <range in terms of words(4-byte)> <seed>\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"To check data pattern with absolute address: C8 <addr> <range in terms of words(4-byte)> <seed> -a\r\n");PRINTF;
	uart_num=sprintf(uplink_buffer,"Current blocks status:\r\n");PRINTF;
	UINT8_t flag_displayed =0;
	for(UINT8_t i=0;i<MAX_BLOCK;i++){
		if(mem[i].obsolete == 1){
			uart_num=sprintf(uplink_buffer,"block%d, capacity:0x%x words (0x%x bytes), address: %p\n\r",i,mem[i].range,mem[i].range*4,mem[i].mem_ptr);PRINTF;
			flag_displayed=1;
		}
	}
	if(flag_displayed==0){
		uart_num=sprintf(uplink_buffer,"no block assigned\n\r");PRINTF;
	}
}

/**
*	@brief 		Printf the information for users while receiving C1
*	exit the application only supported on the linux
*	@return   	void.
*/
void exit_project(param* params_input){
	uart_num=sprintf(uplink_buffer,"exit the application doesn't support on the FRDM\r\n");PRINTF;
	return;
}


/**
*	@brief 		Check event with the command index provided by parser.c
*
*	@param		index			command input
*   - value = 0		Show the help message for all command
*   - value = 1		End the program
*   - value = 2		Allocate a heap of memory into block		(more detail are in allocate.c)
*   - value = 3		Free the block memory with block index 	(more detail are in free_mem.c)
*   - value = 4		Display the data in specific address 		(more detail are in display.c)
*   - value = 5		Write the data into specific address 		(more detail are in write_mem.c)
*   - value = 6		Invert the data in specific address			(more detail are in invert.c)
*
*	@return   	void.
*/
evt_ptr_type evt_regi[] ={&help_message,&exit_project,&allocate,&free_mem,&display,&write_mem,&invert,&PRG,&pattern_check};
INT8_t evt_handler(INT8_t index){
	INT8_t evt_trigger=1;
	evt_ptr =NULL;
	if(index>=0 && index <=8)
		evt_ptr=evt_regi[(UINT32_t)index];
	else{
		uart_num=sprintf(uplink_buffer,"Command Not defined\r\n");PRINTF;
		evt_trigger =0;
	}
	return evt_trigger;
}

/*!
 * @brief Main function
 */
int main(void)
{
    lpsci_config_t config;
    INT8_t command_index;
    BOARD_InitPins();
    BOARD_BootClockRUN();
    CLOCK_SetLpsci0Clock(0x1U);
    us_10=0;
    second=0;
    SysTick_Config(480);
    /*
     * config.parityMode = kLPSCI_ParityDisabled;
     * config.stopBitCount = kLPSCI_OneStopBit;
     * config.enableTx = false;
     * config.enableRx = false;
     */
    LPSCI_GetDefaultConfig(&config);
    config.baudRate_Bps = BOARD_DEBUG_UART_BAUDRATE;
    config.enableTx = true;
    config.enableRx = true;

    LPSCI_Init(DEMO_LPSCI, &config, DEMO_LPSCI_CLK_FREQ);

    /* Send initial message out. */
    inital_message();

    /* Enable RX interrupt. */
    LPSCI_EnableInterrupts(DEMO_LPSCI, kLPSCI_RxDataRegFullInterruptEnable);
    EnableIRQ(DEMO_LPSCI_IRQn);
    /* working loop*/
    while (1)
    {
    	/* main loop */
		if(command_flag){
			if(cnt_charactor == 0){
				buffer_ptr =0;
				command_flag = 0;
				buffer[0]=0;
				memset((char *)buffer,0,255);
				break;
			}
			command_index = parser((char* )buffer,&output);
			if( (evt_handler(command_index)) != 0)
				evt_ptr(&output);
			uart_num=sprintf(uplink_buffer,"\n\n\r");PRINTF;
			cnt_charactor =0;
			buffer_ptr =0;
			command_flag = 0;
		}
    }
}
